/**
 * SEO source of truth.
 *
 * Every page's title, description, canonical, Open Graph, Twitter card and
 * JSON-LD comes from here. The prerender script reads this at build time
 * and bakes it into each route's static HTML, so crawlers and AI engines
 * get everything without running JavaScript.
 *
 * Change business facts once, here. Do not scatter them across components.
 */

export const SITE = {
  url: "https://www.ronlenserdigital.com",
  name: "Ron Lenser Digital",
  legalName: "Ron Lenser Digital",
  founder: "Ron Lenser",
  phone: "+1-540-395-6493",
  phoneDisplay: "(540) 395-6493",
  email: "ron@ronlenserdigital.com",
  city: "Fredericksburg",
  region: "VA",
  regionLong: "Virginia",
  country: "US",
  lat: 38.3032,
  lng: -77.4605,
  ogImage: "/og.png",
  logo: "/icon-512.png",
  social: [
    "https://www.facebook.com/ronlenserdigital",
    "https://linkedin.com/in/ronlenser",
    "https://github.com/ronlenserdigital",
    "https://github.com/RonaldLenser",
  ],
  hours: "Mo-Sa 08:00-19:00",
  areaServed: [
    "Fredericksburg",
    "Stafford",
    "Spotsylvania",
    "King George",
    "Caroline County",
    "Culpeper",
    "Orange",
    "Northern Virginia",
  ],
  services: [
    "Custom website design",
    "Web app development",
    "Internal tools and dashboards",
    "Business automation",
    "AI chatbot and AI phone answering",
    "Local SEO and Google Business Profile",
    "Logo and brand design",
  ],
};

/* Per route. Path is the key. `index: false` keeps a page out of search. */
export const PAGES = {
  "/": {
    title: "Ron Lenser Digital | Websites, Apps and Automations in Fredericksburg VA",
    description:
      "Custom websites, web apps and automations for Fredericksburg, Virginia businesses. Built with AI by one person, shipped in days, and you own everything. Fixed quote before work starts.",
    type: "website",
  },
  "/privacy": {
    title: "Privacy Policy | Ron Lenser Digital",
    description:
      "What ronlenserdigital.com collects, why, and what happens to it. Short version: the quote form, cookieless analytics, nothing sold.",
    type: "article",
    index: true,
  },
  "/terms": {
    title: "Terms of Service | Ron Lenser Digital",
    description:
      "Terms for working with Ron Lenser Digital. Fixed quotes, ownership of the finished work, payment, and what happens if either side walks away.",
    type: "article",
    index: true,
  },
  "/services": {
    title: "Services | Websites, Apps, Automations and Local SEO | Ron Lenser Digital",
    description:
      "Everything Ron Lenser Digital builds for Fredericksburg area businesses: websites, web apps, internal tools, automations, AI answering and local SEO. Fixed quotes in writing, no retainers.",
    type: "website",
    priority: "0.8",
  },
  "/services/local-seo": {
    title: "Local SEO Fredericksburg VA | Get Found on Google | Ron Lenser Digital",
    description:
      "Local SEO for Fredericksburg businesses: Google Business Profile, service area pages, schema markup and reviews. One fixed quote in writing, no retainer, no ranking promises.",
    type: "website",
    priority: "0.8",
  },
  "/work": {
    title: "Work | Websites and Web Apps Built in Fredericksburg VA | Ron Lenser Digital",
    description:
      "Portfolio of websites, web apps and automations built by Ron Lenser Digital for contractors, insurance agents, restaurants, brands and coaches. Live links and public source code for every project.",
    type: "website",
    priority: "0.8",
  },
  "/work/lead-gen-automation": {
    title: "Lead Gen Automation | n8n Case Study | Ron Lenser Digital",
    description:
      "How Ron Lenser built a six workflow n8n automation that finds local businesses with no website, verifies it nine ways, writes personal emails with Claude, sorts replies and builds a sales pipeline.",
    type: "article",
    priority: "0.7",
  },
  "/resume": {
    title: "Ron Lenser | Resume | AI First Engineer and Workflow Automation",
    description:
      "Resume and portfolio of Ron Lenser, AI first engineer in Fredericksburg VA. AI applications, workflow automation, encrypted messaging, RAG with citation checks, and 50+ shipped websites.",
    type: "profile",
    priority: "0.8",
  },
  "/404": {
    title: "Page not found | Ron Lenser Digital",
    description: "That page does not exist. The site is one page, so everything is a scroll away.",
    type: "website",
    index: false,
  },
};

import { AREAS } from "./areas.js";
import { ANSWERS } from "./answers.js";
PAGES["/answers"] = {
  title: "Answers | Questions People Ask Before Hiring Me | Ron Lenser Digital",
  description:
    "Straight answers on cost, timelines, ownership and building with AI. The same answers Ron gives on the phone, from a one person build shop in Fredericksburg VA.",
  type: "website",
  priority: "0.7",
};
for (const a of ANSWERS) {
  PAGES[`/answers/${a.slug}`] = {
    title: a.title,
    description: a.description,
    type: "article",
    answer: a,
    priority: "0.7",
  };
}

for (const a of AREAS) {
  PAGES[`/${a.slug}`] = {
    title: a.title,
    description: a.description,
    type: "website",
    area: a,
  };
}

export function pageFor(path) {
  const clean = path.replace(/\/+$/, "") || "/";
  return { path: clean, ...(PAGES[clean] ?? PAGES["/404"]) };
}

/* The FAQ answers live in faq-section.jsx. They are imported here so the
   FAQPage schema and the visible accordion can never drift apart. */
import { LEFT, RIGHT } from "./components/ui/faq-section.jsx";
import { LOCAL_SEO_FAQ } from "./pages/LocalSeo.jsx";

export function jsonLd(path) {
  const page = pageFor(path);
  const abs = (p) => SITE.url + p;

  const business = {
    "@type": ["ProfessionalService", "LocalBusiness"],
    "@id": abs("/#business"),
    name: SITE.name,
    legalName: SITE.legalName,
    url: SITE.url,
    logo: abs(SITE.logo),
    image: abs(SITE.ogImage),
    telephone: SITE.phone,
    email: SITE.email,
    priceRange: "$$",
    description: PAGES["/"].description,
    founder: { "@id": abs("/#ron") },
    address: {
      "@type": "PostalAddress",
      addressLocality: SITE.city,
      addressRegion: SITE.region,
      addressCountry: SITE.country,
    },
    geo: { "@type": "GeoCoordinates", latitude: SITE.lat, longitude: SITE.lng },
    areaServed: SITE.areaServed.map((name) => ({ "@type": "Place", name })),
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      opens: "08:00",
      closes: "19:00",
    },
    sameAs: SITE.social,
    knowsAbout: [
      "Web design",
      "Web development",
      "AI-assisted software development",
      "Business automation",
      "Local SEO",
      "Small business software",
    ],
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: "Services",
      itemListElement: SITE.services.map((s) => ({
        "@type": "Offer",
        itemOffered: { "@type": "Service", name: s, provider: { "@id": abs("/#business") } },
      })),
    },
  };

  const person = {
    "@type": "Person",
    "@id": abs("/#ron"),
    name: SITE.founder,
    jobTitle: "Founder",
    worksFor: { "@id": abs("/#business") },
    url: SITE.url,
    image: abs("/ron-portrait.jpg"),
    telephone: SITE.phone,
    email: SITE.email,
    sameAs: SITE.social,
    homeLocation: { "@type": "Place", name: `${SITE.city}, ${SITE.regionLong}` },
  };

  const website = {
    "@type": "WebSite",
    "@id": abs("/#website"),
    url: SITE.url,
    name: SITE.name,
    publisher: { "@id": abs("/#business") },
    inLanguage: "en-US",
  };

  const webpage = {
    "@type": "WebPage",
    "@id": abs(page.path === "/" ? "/#webpage" : page.path + "#webpage"),
    url: abs(page.path === "/" ? "/" : page.path),
    name: page.title,
    description: page.description,
    isPartOf: { "@id": abs("/#website") },
    about: { "@id": abs("/#business") },
    inLanguage: "en-US",
  };

  const graph = [business, person, website, webpage];

  if (page.path === "/") {
    graph.push({
      "@type": "FAQPage",
      "@id": abs("/#faq"),
      mainEntity: [...LEFT, ...RIGHT].map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    });
  } else if (page.answer) {
    // FAQPage, not QAPage. QAPage is defined for pages where users submit
    // multiple competing answers to a question, like a forum thread. These
    // pages carry one authoritative answer from the business, so QAPage was
    // the wrong vocabulary and is now corrected.
    //
    // Note this markup earns no rich result: Google deprecated FAQ rich
    // results on 7 May 2026. It stays because FAQPage remains valid
    // Schema.org, Google confirms unused structured data is harmless, and
    // other crawlers still read it. Do not re-add it expecting SERP
    // decoration.
    graph.push(
      {
        "@type": "FAQPage",
        "@id": abs(page.path + "#faq"),
        mainEntity: [
          {
            "@type": "Question",
            name: page.answer.question,
            acceptedAnswer: {
              "@type": "Answer",
              text: page.answer.short,
              url: abs(page.path),
            },
          },
        ],
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: SITE.url + "/" },
          { "@type": "ListItem", position: 2, name: "Answers", item: abs("/answers") },
          { "@type": "ListItem", position: 3, name: page.answer.question, item: abs(page.path) },
        ],
      }
    );
  } else if (page.path === "/answers") {
    graph.push({
      "@type": "FAQPage",
      "@id": abs("/answers#faq"),
      mainEntity: ANSWERS.map((a) => ({
        "@type": "Question",
        name: a.question,
        acceptedAnswer: { "@type": "Answer", text: a.short, url: abs(`/answers/${a.slug}`) },
      })),
    });
  } else if (page.path === "/services/local-seo") {
    graph.push(
      {
        "@type": "Service",
        "@id": abs(page.path + "#service"),
        name: "Local SEO in Fredericksburg, Virginia",
        serviceType: "Local search engine optimization",
        provider: { "@id": abs("/#business") },
        areaServed: SITE.areaServed.map((name) => ({ "@type": "Place", name })),
        description: page.description,
      },
      {
        "@type": "FAQPage",
        "@id": abs(page.path + "#faq"),
        mainEntity: LOCAL_SEO_FAQ.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: SITE.url + "/" },
          { "@type": "ListItem", position: 2, name: "Services", item: abs("/services") },
          { "@type": "ListItem", position: 3, name: "Local SEO", item: abs(page.path) },
        ],
      }
    );
  } else if (page.area) {
    const a = page.area;
    graph.push(
      {
        "@type": "Service",
        "@id": abs(page.path + "#service"),
        name: `Web design and software development in ${a.city}, Virginia`,
        serviceType: "Web design",
        provider: { "@id": abs("/#business") },
        areaServed: { "@type": "Place", name: `${a.city}, Virginia` },
        description: a.description,
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: SITE.url + "/" },
          { "@type": "ListItem", position: 2, name: `${a.city}, VA`, item: abs(page.path) },
        ],
      }
    );
  } else {
    graph.push({
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: SITE.url + "/" },
        { "@type": "ListItem", position: 2, name: page.title.split(" | ")[0], item: abs(page.path) },
      ],
    });
  }

  return { "@context": "https://schema.org", "@graph": graph };
}

/* Head tags as a string. Used by the prerender script only. */
export function headHtml(path) {
  const page = pageFor(path);
  const url = SITE.url + (page.path === "/" ? "/" : page.path);
  const img = SITE.url + SITE.ogImage;
  const robots = page.index === false ? "noindex, nofollow" : "index, follow, max-image-preview:large, max-snippet:-1";
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

  return [
    `<title>${esc(page.title)}</title>`,
    `<meta name="description" content="${esc(page.description)}" />`,
    `<meta name="robots" content="${robots}" />`,
    `<link rel="canonical" href="${url}" />`,
    `<meta name="author" content="${SITE.founder}" />`,
    `<meta name="geo.region" content="US-VA" />`,
    `<meta name="geo.placename" content="${SITE.city}" />`,
    `<meta name="geo.position" content="${SITE.lat};${SITE.lng}" />`,
    `<meta name="ICBM" content="${SITE.lat}, ${SITE.lng}" />`,
    `<meta property="og:site_name" content="${SITE.name}" />`,
    `<meta property="og:locale" content="en_US" />`,
    `<meta property="og:type" content="${page.type}" />`,
    `<meta property="og:url" content="${url}" />`,
    `<meta property="og:title" content="${esc(page.title)}" />`,
    `<meta property="og:description" content="${esc(page.description)}" />`,
    `<meta property="og:image" content="${img}" />`,
    `<meta property="og:image:width" content="1200" />`,
    `<meta property="og:image:height" content="630" />`,
    `<meta property="og:image:alt" content="${SITE.name}. Websites, apps and automations built with AI in Fredericksburg, Virginia." />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${esc(page.title)}" />`,
    `<meta name="twitter:description" content="${esc(page.description)}" />`,
    `<meta name="twitter:image" content="${img}" />`,
    `<script type="application/ld+json">${JSON.stringify(jsonLd(page.path))}</script>`,
  ].join("\n    ");
}
